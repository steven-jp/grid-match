export const ItemTypes = {
  CARD: "card",
  GRID: "grid",
};
